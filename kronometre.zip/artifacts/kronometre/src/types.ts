export interface Ders {
  id: string;
  name: string;
  color: string;
}

export type Mod = 'kronometre' | 'pomodoro';

export interface Seans {
  id: string;
  dersId: string;
  dersAdi: string;
  sure: number; // seconds
  baslamaSaati: string; // ISO date
  mod: Mod;
}

export type Theme = 'uzay' | 'galaksi' | 'orman' | 'yagmur' | 'okyanus' | 'gece';
export type Sound = 'sessizlik' | 'yagmur' | 'orman' | 'okyanus' | 'fısıltı';

export interface AppState {
  activeDersId: string | null;
  theme: Theme;
  sound: Sound;
  volume: number; // 0-100
}
