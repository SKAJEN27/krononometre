import { useState, useEffect } from 'react';
import { Mod, Theme, Sound } from './types';
import { useTimer } from './hooks/use-timer';
import { useDersler } from './hooks/use-dersler';
import { useSeanslar } from './hooks/use-seanslar';
import { useAmbientSound } from './hooks/use-ambient-sound';
import { useLocalStorage } from './hooks/use-local-storage';

import { Background } from './components/Background';
import { DersSelector } from './components/DersSelector';
import { StatsView } from './components/StatsView';
import { SoundSelector } from './components/SoundSelector';
import { ThemeSelector } from './components/ThemeSelector';

import { motion, AnimatePresence } from 'framer-motion';
import { Play, Pause, Square, BarChart3, ChevronDown, Clock, Timer as TimerIcon } from 'lucide-react';

export default function App() {
  // App State
  const [mod, setMod] = useLocalStorage<Mod>('calisma_mod', 'kronometre');
  const [theme, setTheme] = useLocalStorage<Theme>('calisma_theme', 'gece');
  const [sound, setSound] = useLocalStorage<Sound>('calisma_sound', 'sessizlik');
  const [volume, setVolume] = useLocalStorage<number>('calisma_volume', 50);
  const [activeDersId, setActiveDersId] = useLocalStorage<string | null>('calisma_active_ders', null);

  // UI State
  const [isDersSelectorOpen, setIsDersSelectorOpen] = useState(false);
  const [isStatsOpen, setIsStatsOpen] = useState(false);

  // Hooks
  const { dersler } = useDersler();
  const { addSeans } = useSeanslar();
  
  const activeDers = dersler.find(d => d.id === activeDersId);

  const handleSessionSave = (duration: number) => {
    if (activeDers && duration > 10) {
      addSeans(activeDers.id, activeDers.name, duration, mod);
    }
  };

  const {
    formattedTime,
    isRunning,
    phase,
    cycles,
    toggle,
    stopAndSave
  } = useTimer({
    mod,
    onPhaseComplete: () => {
      playChime();
    },
    onSessionSave: handleSessionSave
  });

  const { playChime } = useAmbientSound(sound, volume, isRunning);

  const handleToggle = () => {
    if (!activeDers) {
      setIsDersSelectorOpen(true);
      return;
    }
    toggle();
  };

  // Switch mode handling
  const setModeAndStop = (newMod: Mod) => {
    if (isRunning) stopAndSave();
    setMod(newMod);
  };

  return (
    <div className="min-h-[100dvh] w-full flex flex-col items-center justify-center relative overflow-hidden font-sans select-none">
      <Background theme={theme} />

      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-start z-10">
        <div className="flex flex-col gap-4">
          <ThemeSelector theme={theme} onChange={setTheme} />
          <SoundSelector 
            sound={sound} 
            volume={volume} 
            onSoundChange={setSound} 
            onVolumeChange={setVolume} 
          />
        </div>
        
        <button
          onClick={() => setIsStatsOpen(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-2xl glass-panel text-white/80 hover:text-white transition-all hover:scale-105"
        >
          <BarChart3 className="w-5 h-5" />
          <span className="font-medium">İstatistikler</span>
        </button>
      </div>

      {/* Main Timer Area */}
      <main className="relative z-10 flex flex-col items-center justify-center w-full max-w-2xl px-6">
        
        {/* Mode Selector */}
        <div className="flex p-1 mb-12 rounded-full glass-panel">
          <button
            onClick={() => setModeAndStop('kronometre')}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-medium transition-all ${
              mod === 'kronometre' ? 'bg-white text-black shadow-md' : 'text-white/60 hover:text-white'
            }`}
          >
            <Clock className="w-4 h-4" />
            Kronometre
          </button>
          <button
            onClick={() => setModeAndStop('pomodoro')}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-medium transition-all ${
              mod === 'pomodoro' ? 'bg-white text-black shadow-md' : 'text-white/60 hover:text-white'
            }`}
          >
            <TimerIcon className="w-4 h-4" />
            Pomodoro
          </button>
        </div>

        {/* Active Subject Pill */}
        <button
          onClick={() => setIsDersSelectorOpen(true)}
          className="flex items-center gap-3 px-6 py-3 mb-8 transition-all rounded-full glass-panel hover:bg-white/10 group"
        >
          {activeDers ? (
            <>
              <div 
                className="w-3 h-3 rounded-full shadow-[0_0_10px_rgba(255,255,255,0.5)]" 
                style={{ backgroundColor: activeDers.color }} 
              />
              <span className="text-lg font-medium text-white">{activeDers.name}</span>
            </>
          ) : (
            <span className="text-lg font-medium text-white/60">Ders Seçin</span>
          )}
          <ChevronDown className="w-4 h-4 text-white/40 group-hover:text-white/80" />
        </button>

        {/* Timer Display */}
        <div className="relative flex flex-col items-center justify-center mb-16">
          <AnimatePresence mode="wait">
            <motion.div
              key={mod + phase}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative text-[120px] leading-none font-bold text-white timer-text drop-shadow-[0_0_30px_rgba(255,255,255,0.2)] tracking-tighter"
            >
              {formattedTime}
            </motion.div>
          </AnimatePresence>

          {mod === 'pomodoro' && (
            <div className="absolute -bottom-8 flex items-center gap-4 text-white/80 font-medium">
              <span className={`px-3 py-1 rounded-full text-sm border ${phase === 'calisma' ? 'bg-white/20 border-white/40 text-white' : 'border-transparent'}`}>
                Çalışma
              </span>
              <span className={`px-3 py-1 rounded-full text-sm border ${phase === 'mola' ? 'bg-white/20 border-white/40 text-white' : 'border-transparent'}`}>
                Mola
              </span>
              {cycles > 0 && (
                <span className="text-sm opacity-60 ml-2">({cycles} tamamlandı)</span>
              )}
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="flex items-center gap-6">
          <button
            onClick={handleToggle}
            className={`flex items-center justify-center w-24 h-24 rounded-full transition-all duration-300 hover:scale-105 active:scale-95 shadow-2xl ${
              isRunning 
                ? 'bg-white/20 text-white backdrop-blur-md border-2 border-white/30' 
                : 'bg-white text-black'
            }`}
          >
            {isRunning ? <Pause className="w-10 h-10" /> : <Play className="w-10 h-10 ml-2" />}
          </button>
          
          <AnimatePresence>
            {isRunning || (!isRunning && formattedTime !== (mod === 'pomodoro' ? '25:00' : '00:00')) ? (
              <motion.button
                initial={{ opacity: 0, scale: 0.5, x: -20 }}
                animate={{ opacity: 1, scale: 1, x: 0 }}
                exit={{ opacity: 0, scale: 0.5, x: -20 }}
                onClick={stopAndSave}
                className="flex items-center justify-center w-16 h-16 transition-all border border-white/20 rounded-full glass-panel text-white/80 hover:text-white hover:bg-white/20 hover:scale-105 active:scale-95"
              >
                <Square className="w-6 h-6" fill="currentColor" />
              </motion.button>
            ) : null}
          </AnimatePresence>
        </div>
      </main>

      {/* Modals */}
      <DersSelector 
        isOpen={isDersSelectorOpen} 
        onClose={() => setIsDersSelectorOpen(false)} 
        activeDersId={activeDersId}
        onSelect={setActiveDersId}
      />
      
      <StatsView 
        isOpen={isStatsOpen} 
        onClose={() => setIsStatsOpen(false)} 
      />
    </div>
  );
}
