import { useEffect, useRef } from 'react';
import { Sound } from '../types';

export function useAmbientSound(soundType: Sound, volume: number, isPlaying: boolean) {
  const audioContextRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const sourcesRef = useRef<any[]>([]);

  useEffect(() => {
    // Only create AudioContext when first needed
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    
    const ctx = audioContextRef.current;
    
    // Stop all current sources
    sourcesRef.current.forEach(source => {
      if (source.stop) source.stop();
      if (source.disconnect) source.disconnect();
    });
    sourcesRef.current = [];

    if (!isPlaying || soundType === 'sessizlik') {
      return;
    }

    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    // Master gain
    if (!gainNodeRef.current) {
      gainNodeRef.current = ctx.createGain();
      gainNodeRef.current.connect(ctx.destination);
    }
    
    // Convert 0-100 to 0.0-1.0, with a logarithmic scale for better perceived volume
    const normalizedVol = volume / 100;
    // Cap max volume depending on sound type as some are very loud
    const maxVol = soundType === 'fısıltı' ? 0.8 : 0.5;
    gainNodeRef.current.gain.value = (normalizedVol * normalizedVol) * maxVol;

    // Generator helpers
    const createNoise = (type: 'white' | 'pink' | 'brown') => {
      const bufferSize = 2 * ctx.sampleRate;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      
      let lastOut = 0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        if (type === 'white') {
          output[i] = white;
        } else if (type === 'pink') {
          // Paul Kellet's refined method
          const b0 = 0.99886 * (Math.random() * 2 - 1);
          const b1 = 0.99332 * (Math.random() * 2 - 1);
          const b2 = 0.96900 * (Math.random() * 2 - 1);
          const b3 = 0.86650 * (Math.random() * 2 - 1);
          const b4 = 0.55000 * (Math.random() * 2 - 1);
          const b5 = -0.7616 * (Math.random() * 2 - 1);
          output[i] = b0 + b1 + b2 + b3 + b4 + b5 + white * 0.5362;
          output[i] *= 0.11; // compensate gain
        } else if (type === 'brown') {
          output[i] = (lastOut + (0.02 * white)) / 1.02;
          lastOut = output[i];
          output[i] *= 3.5; // compensate gain
        }
      }

      const noise = ctx.createBufferSource();
      noise.buffer = noiseBuffer;
      noise.loop = true;
      return noise;
    };

    if (soundType === 'yagmur') {
      const noise = createNoise('pink');
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 1000;
      
      noise.connect(filter);
      filter.connect(gainNodeRef.current);
      noise.start();
      sourcesRef.current.push(noise, filter);
    } 
    else if (soundType === 'orman') {
      const noise = createNoise('brown');
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 400;
      
      // Rustle effect LFO
      const lfo = ctx.createOscillator();
      lfo.type = 'sine';
      lfo.frequency.value = 0.2; // very slow
      
      const lfoGain = ctx.createGain();
      lfoGain.gain.value = 200;
      lfo.connect(lfoGain);
      lfoGain.connect(filter.frequency);

      noise.connect(filter);
      filter.connect(gainNodeRef.current);
      
      noise.start();
      lfo.start();
      sourcesRef.current.push(noise, filter, lfo, lfoGain);
    }
    else if (soundType === 'okyanus') {
      const noise = createNoise('pink');
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 800;

      // Wave rhythm LFO for volume
      const waveGain = ctx.createGain();
      waveGain.gain.value = 0.5;

      const lfo = ctx.createOscillator();
      lfo.type = 'sine';
      lfo.frequency.value = 0.1; // 10 seconds per wave
      
      // We want to scale sine from [-1, 1] to [0, 1] approximately, or just connect to gain
      const lfoScale = ctx.createGain();
      lfoScale.gain.value = 0.4;
      lfo.connect(lfoScale);
      lfoScale.connect(waveGain.gain);

      noise.connect(filter);
      filter.connect(waveGain);
      waveGain.connect(gainNodeRef.current);

      noise.start();
      lfo.start();
      sourcesRef.current.push(noise, filter, waveGain, lfo, lfoScale);
    }
    else if (soundType === 'fısıltı') {
      const noise = createNoise('brown');
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 150;
      filter.Q.value = 0.5;
      
      noise.connect(filter);
      filter.connect(gainNodeRef.current);
      noise.start();
      sourcesRef.current.push(noise, filter);
    }

    return () => {
      // Cleanup on unmount or deps change
      sourcesRef.current.forEach(source => {
        if (source.stop) {
          try { source.stop(); } catch(e) {}
        }
        if (source.disconnect) {
          try { source.disconnect(); } catch(e) {}
        }
      });
      sourcesRef.current = [];
    };
  }, [soundType, volume, isPlaying]);

  // Expose a chime function for pomodoro intervals
  const playChime = () => {
    if (!audioContextRef.current) return;
    const ctx = audioContextRef.current;
    if (ctx.state === 'suspended') ctx.resume();

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
    osc.frequency.exponentialRampToValueAtTime(1046.50, ctx.currentTime + 0.1); // C6

    gain.gain.setValueAtTime(0, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.5, ctx.currentTime + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.5);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 1.6);
  };

  return { playChime };
}
