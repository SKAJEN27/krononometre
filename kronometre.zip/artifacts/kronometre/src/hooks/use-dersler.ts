import { useLocalStorage } from './use-local-storage';
import { Ders } from '../types';

const DEFAULT_DERSLER: Ders[] = [
  { id: '1', name: 'Matematik', color: '#ef4444' }, // Red
  { id: '2', name: 'Fizik', color: '#3b82f6' }, // Blue
  { id: '3', name: 'Türkçe', color: '#10b981' }, // Green
  { id: '4', name: 'Tarih', color: '#f59e0b' }, // Amber
  { id: '5', name: 'İngilizce', color: '#8b5cf6' }, // Purple
];

export function useDersler() {
  const [dersler, setDersler] = useLocalStorage<Ders[]>('calisma_dersler', DEFAULT_DERSLER);

  const addDers = (name: string, color: string) => {
    const newDers: Ders = {
      id: crypto.randomUUID(),
      name,
      color,
    };
    setDersler([...dersler, newDers]);
    return newDers;
  };

  const deleteDers = (id: string) => {
    setDersler(dersler.filter((d) => d.id !== id));
  };

  return {
    dersler,
    addDers,
    deleteDers,
  };
}
