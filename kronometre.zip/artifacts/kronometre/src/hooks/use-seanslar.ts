import { useLocalStorage } from './use-local-storage';
import { Seans, Mod } from '../types';

export function useSeanslar() {
  const [seanslar, setSeanslar] = useLocalStorage<Seans[]>('calisma_seanslar', []);

  const addSeans = (dersId: string, dersAdi: string, sure: number, mod: Mod) => {
    if (sure < 10) return; // Don't save sessions under 10 seconds

    const newSeans: Seans = {
      id: crypto.randomUUID(),
      dersId,
      dersAdi,
      sure,
      baslamaSaati: new Date().toISOString(),
      mod,
    };
    setSeanslar([newSeans, ...seanslar]);
    return newSeans;
  };

  const clearSeanslar = () => {
    if (confirm('Tüm geçmiş kayıtları silmek istediğinize emin misiniz?')) {
      setSeanslar([]);
    }
  };

  return {
    seanslar,
    addSeans,
    clearSeanslar,
  };
}
