import { useState, useEffect, useRef, useCallback } from 'react';
import { Mod } from '../types';

interface UseTimerProps {
  mod: Mod;
  onPhaseComplete?: () => void;
  onSessionSave?: (duration: number) => void;
}

const POMODORO_WORK = 25 * 60;
const POMODORO_BREAK = 5 * 60;

export function useTimer({ mod, onPhaseComplete, onSessionSave }: UseTimerProps) {
  const [isRunning, setIsRunning] = useState(false);
  const [phase, setPhase] = useState<'calisma' | 'mola'>('calisma');
  const [cycles, setCycles] = useState(0);
  
  // time represents either elapsed time (kronometre) or remaining time (pomodoro)
  const [time, setTime] = useState(mod === 'pomodoro' ? POMODORO_WORK : 0);
  
  // Track total elapsed time for session saving (in kronometre mode it's just 'time', in pomodoro it's WORK - time)
  const [sessionDuration, setSessionDuration] = useState(0);

  const timerRef = useRef<number | null>(null);

  // Initialize time when mode changes
  useEffect(() => {
    if (mod === 'pomodoro') {
      setTime(phase === 'calisma' ? POMODORO_WORK : POMODORO_BREAK);
    } else {
      setTime(0);
      setPhase('calisma');
    }
    setSessionDuration(0);
    setIsRunning(false);
  }, [mod, phase]);

  const tick = useCallback(() => {
    if (mod === 'kronometre') {
      setTime(t => t + 1);
      setSessionDuration(d => d + 1);
    } else {
      setTime(t => {
        if (t <= 1) {
          // Phase complete
          setTimeout(() => {
            if (onPhaseComplete) onPhaseComplete();
            
            if (phase === 'calisma') {
              if (onSessionSave) onSessionSave(POMODORO_WORK);
              setPhase('mola');
            } else {
              setPhase('calisma');
              setCycles(c => c + 1);
            }
          }, 0);
          return 0; // Will be reset by the effect watching `phase`
        }
        setSessionDuration(d => phase === 'calisma' ? d + 1 : d);
        return t - 1;
      });
    }
  }, [mod, phase, onPhaseComplete, onSessionSave]);

  useEffect(() => {
    if (isRunning) {
      timerRef.current = window.setInterval(tick, 1000);
    } else if (timerRef.current) {
      window.clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, [isRunning, tick]);

  const toggle = () => {
    setIsRunning(!isRunning);
  };

  const stopAndSave = () => {
    if (sessionDuration > 0 && phase === 'calisma' && onSessionSave) {
      onSessionSave(sessionDuration);
    }
    setIsRunning(false);
    if (mod === 'pomodoro') {
      setTime(POMODORO_WORK);
      setPhase('calisma');
    } else {
      setTime(0);
    }
    setSessionDuration(0);
  };

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    
    if (mod === 'kronometre' && h > 0) {
      return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return {
    time,
    formattedTime: formatTime(time),
    isRunning,
    phase,
    cycles,
    toggle,
    stopAndSave,
  };
}
