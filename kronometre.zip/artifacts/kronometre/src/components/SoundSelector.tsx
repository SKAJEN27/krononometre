import { motion } from 'framer-motion';
import { Volume2, VolumeX, CloudRain, Wind, Waves, Coffee } from 'lucide-react';
import { Sound } from '../types';

interface SoundSelectorProps {
  sound: Sound;
  volume: number;
  onSoundChange: (sound: Sound) => void;
  onVolumeChange: (vol: number) => void;
}

export function SoundSelector({ sound, volume, onSoundChange, onVolumeChange }: SoundSelectorProps) {
  const sounds: { id: Sound; label: string; icon: React.ReactNode }[] = [
    { id: 'sessizlik', label: 'Sessizlik', icon: <VolumeX className="w-4 h-4" /> },
    { id: 'yagmur', label: 'Yağmur', icon: <CloudRain className="w-4 h-4" /> },
    { id: 'orman', label: 'Orman', icon: <Wind className="w-4 h-4" /> },
    { id: 'okyanus', label: 'Okyanus', icon: <Waves className="w-4 h-4" /> },
    { id: 'fısıltı', label: 'Fısıltı', icon: <Coffee className="w-4 h-4" /> },
  ];

  return (
    <div className="flex items-center gap-4 p-2 rounded-2xl glass-panel">
      <div className="flex gap-1">
        {sounds.map((s) => (
          <button
            key={s.id}
            onClick={() => onSoundChange(s.id)}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-all ${
              sound === s.id 
                ? 'bg-white text-black shadow-lg scale-105' 
                : 'text-white/60 hover:bg-white/10 hover:text-white'
            }`}
            title={s.label}
          >
            {s.icon}
            <span className="hidden md:inline">{s.label}</span>
          </button>
        ))}
      </div>
      
      {sound !== 'sessizlik' && (
        <div className="flex items-center gap-2 pl-4 border-l border-white/20 pr-2">
          <Volume2 className="w-4 h-4 text-white/60" />
          <input
            type="range"
            min="0"
            max="100"
            value={volume}
            onChange={(e) => onVolumeChange(Number(e.target.value))}
            className="w-24 h-1.5 bg-white/20 rounded-full appearance-none outline-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white cursor-pointer"
          />
        </div>
      )}
    </div>
  );
}
