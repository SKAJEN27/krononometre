import { motion, AnimatePresence } from 'framer-motion';
import { Theme } from '../types';
import { useEffect, useState, useRef } from 'react';

// Real video backgrounds from Mixkit (free stock video CDN) + NASA Archive (public domain)
const THEME_VIDEOS: Record<Theme, string> = {
  uzay:    'https://assets.mixkit.co/videos/preview/mixkit-infinite-space-covered-in-stars-and-galaxies-with-gradient-colors-10417-large.mp4',
  galaksi: 'https://assets.mixkit.co/videos/preview/mixkit-traveling-between-the-stars-and-nebulae-14151-large.mp4',
  gece:    'https://assets.mixkit.co/videos/preview/mixkit-night-sky-covered-with-stars-and-galaxies-30018-large.mp4',
  yagmur:  'https://assets.mixkit.co/videos/preview/mixkit-heavy-rain-on-a-dark-screen-28087-large.mp4',
  orman:   'https://assets.mixkit.co/videos/preview/mixkit-dark-forest-clearing-8330-large.mp4',
  okyanus: 'https://assets.mixkit.co/videos/preview/mixkit-dark-ocean-water-flowing-in-slow-motion-45612-large.mp4',
};

// Fallback solid colors if video fails to load
const THEME_FALLBACK: Record<Theme, string> = {
  uzay:    'radial-gradient(ellipse at center, #1a0b3e 0%, #080415 100%)',
  galaksi: 'radial-gradient(ellipse at center, #2e0b3f 0%, #100520 100%)',
  gece:    'radial-gradient(ellipse at center, #0b1a30 0%, #04090f 100%)',
  yagmur:  'linear-gradient(to bottom, #1b202a 0%, #0a0d14 100%)',
  orman:   'radial-gradient(ellipse at bottom, #0b2e1b 0%, #050f08 100%)',
  okyanus: 'radial-gradient(ellipse at bottom, #08293d 0%, #02111d 100%)',
};

// Overlay opacity per theme (darker themes need less overlay)
const OVERLAY_OPACITY: Record<Theme, number> = {
  uzay:    0.35,
  galaksi: 0.3,
  gece:    0.4,
  yagmur:  0.5,
  orman:   0.45,
  okyanus: 0.4,
};

export function Background({ theme }: { theme: Theme }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoError, setVideoError] = useState(false);
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [currentTheme, setCurrentTheme] = useState(theme);

  // Reset error state when theme changes
  useEffect(() => {
    setVideoError(false);
    setVideoLoaded(false);
    setCurrentTheme(theme);
  }, [theme]);

  // Ensure video plays (browsers may block autoplay without user interaction)
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.play().catch(() => {
      // Autoplay blocked — video will still show first frame
    });
  }, [currentTheme, videoLoaded]);

  const [particles] = useState(() =>
    Array.from({ length: 60 }).map((_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2.5 + 0.5,
      delay: Math.random() * 6,
      duration: Math.random() * 4 + 2,
    }))
  );

  return (
    <div className="fixed inset-0 z-[-1] overflow-hidden">
      {/* Fallback gradient (shown while video loads or on error) */}
      <div
        className="absolute inset-0 transition-all duration-1000"
        style={{ background: THEME_FALLBACK[theme] }}
      />

      {/* Real video background */}
      <AnimatePresence mode="wait">
        <motion.video
          key={theme}
          ref={videoRef}
          src={THEME_VIDEOS[theme]}
          autoPlay
          muted
          loop
          playsInline
          onCanPlay={() => setVideoLoaded(true)}
          onError={() => setVideoError(true)}
          initial={{ opacity: 0 }}
          animate={{ opacity: videoLoaded && !videoError ? 1 : 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.5, ease: 'easeInOut' }}
          className="absolute inset-0 w-full h-full object-cover"
          style={{ display: videoError ? 'none' : 'block' }}
        />
      </AnimatePresence>

      {/* Dark overlay for readability */}
      <div
        className="absolute inset-0 transition-all duration-1000"
        style={{ backgroundColor: `rgba(0,0,0,${OVERLAY_OPACITY[theme]})` }}
      />

      {/* Extra atmospheric particle layer for space themes */}
      {(theme === 'uzay' || theme === 'gece' || theme === 'galaksi') && (
        <div className="absolute inset-0 pointer-events-none">
          {particles.slice(0, 40).map((el) => (
            <div
              key={el.id}
              className="absolute rounded-full bg-white"
              style={{
                left: `${el.x}%`,
                top: `${el.y}%`,
                width: `${el.size}px`,
                height: `${el.size}px`,
                opacity: 0.15,
                animation: `twinkle ${el.duration}s ease-in-out ${el.delay}s infinite alternate`,
                boxShadow: theme === 'galaksi'
                  ? `0 0 ${el.size * 3}px rgba(180,120,255,0.6)`
                  : `0 0 ${el.size}px rgba(255,255,255,0.4)`,
              }}
            />
          ))}
        </div>
      )}

      {/* Rain particles overlay on top of video */}
      {theme === 'yagmur' && (
        <div className="absolute inset-0 pointer-events-none">
          {particles.map((el) => (
            <div
              key={el.id}
              className="absolute"
              style={{
                left: `${el.x}%`,
                top: '-5%',
                width: '1px',
                height: `${el.size * 8 + 10}px`,
                backgroundColor: 'rgba(180,210,255,0.15)',
                animation: `rain ${el.duration * 0.4}s linear ${el.delay * 0.3}s infinite`,
              }}
            />
          ))}
        </div>
      )}

      {/* Ocean shimmer overlay */}
      {theme === 'okyanus' && (
        <div className="absolute bottom-0 left-0 right-0 h-[20vh] pointer-events-none">
          <div
            className="absolute bottom-0 left-[-10%] w-[120%] h-full opacity-15"
            style={{
              background: 'radial-gradient(ellipse at center bottom, rgba(30,160,220,0.4) 0%, transparent 70%)',
              animation: 'wave 10s ease-in-out infinite alternate',
            }}
          />
        </div>
      )}

      {/* Forest mist at bottom */}
      {theme === 'orman' && (
        <div
          className="absolute bottom-0 left-0 right-0 h-[25vh] pointer-events-none"
          style={{
            background: 'linear-gradient(to top, rgba(0,0,0,0.5) 0%, transparent 100%)',
          }}
        />
      )}
    </div>
  );
}
