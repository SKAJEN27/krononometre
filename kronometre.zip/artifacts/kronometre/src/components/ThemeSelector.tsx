import { motion } from 'framer-motion';
import { Theme } from '../types';
import { Palette } from 'lucide-react';

interface ThemeSelectorProps {
  theme: Theme;
  onChange: (theme: Theme) => void;
}

export function ThemeSelector({ theme, onChange }: ThemeSelectorProps) {
  const themes: { id: Theme; label: string; color: string }[] = [
    { id: 'uzay', label: 'Uzay', color: '#1a0b2e' },
    { id: 'galaksi', label: 'Galaksi', color: '#2e0b1f' },
    { id: 'orman', label: 'Orman', color: '#0b2e1b' },
    { id: 'yagmur', label: 'Yağmur', color: '#1b202a' },
    { id: 'okyanus', label: 'Okyanus', color: '#08293d' },
    { id: 'gece', label: 'Gece', color: '#0b1a30' },
  ];

  return (
    <div className="flex items-center gap-2 p-2 rounded-2xl glass-panel group">
      <div className="px-2 text-white/60 group-hover:text-white/90 transition-colors">
        <Palette className="w-4 h-4" />
      </div>
      <div className="flex gap-1">
        {themes.map((t) => (
          <button
            key={t.id}
            onClick={() => onChange(t.id)}
            className={`w-8 h-8 rounded-full transition-all relative ${
              theme === t.id ? 'scale-125 z-10 ring-2 ring-white shadow-lg' : 'opacity-70 hover:opacity-100 hover:scale-110'
            }`}
            style={{ backgroundColor: t.color, border: '1px solid rgba(255,255,255,0.2)' }}
            title={t.label}
          />
        ))}
      </div>
    </div>
  );
}
