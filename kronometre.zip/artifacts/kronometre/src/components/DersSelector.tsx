import { motion, AnimatePresence } from 'framer-motion';
import { Ders } from '../types';
import { X, Plus, Trash2, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';
import { useDersler } from '../hooks/use-dersler';

interface DersSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  activeDersId: string | null;
  onSelect: (id: string) => void;
}

const COLORS = ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#14b8a6'];

export function DersSelector({ isOpen, onClose, activeDersId, onSelect }: DersSelectorProps) {
  const { dersler, addDers, deleteDers } = useDersler();
  const [isAdding, setIsAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [selectedColor, setSelectedColor] = useState(COLORS[0]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    addDers(newName.trim(), selectedColor);
    setNewName('');
    setIsAdding(false);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="w-full max-w-md overflow-hidden rounded-3xl glass-panel text-white"
          >
            <div className="flex items-center justify-between p-6 border-b border-white/10">
              <h2 className="text-xl font-semibold">Ders Seç</h2>
              <button
                onClick={onClose}
                className="p-2 transition-colors rounded-full hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 max-h-[60vh] overflow-y-auto">
              {isAdding ? (
                <form onSubmit={handleAdd} className="p-4 mb-4 rounded-xl bg-white/5 border border-white/10">
                  <input
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="Ders adı..."
                    className="w-full px-4 py-2 mb-4 text-white placeholder-white/50 bg-black/40 rounded-lg outline-none focus:ring-2 focus:ring-white/30"
                    autoFocus
                  />
                  <div className="flex gap-2 mb-6 flex-wrap">
                    {COLORS.map(color => (
                      <button
                        key={color}
                        type="button"
                        onClick={() => setSelectedColor(color)}
                        className={`w-8 h-8 rounded-full flex items-center justify-center transition-transform ${selectedColor === color ? 'scale-125 ring-2 ring-white' : 'opacity-70 hover:opacity-100'}`}
                        style={{ backgroundColor: color }}
                      >
                        {selectedColor === color && <CheckCircle2 className="w-4 h-4 text-white/90" />}
                      </button>
                    ))}
                  </div>
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setIsAdding(false)}
                      className="px-4 py-2 text-sm font-medium transition-colors rounded-lg hover:bg-white/10"
                    >
                      İptal
                    </button>
                    <button
                      type="submit"
                      disabled={!newName.trim()}
                      className="px-4 py-2 text-sm font-medium text-black transition-colors bg-white rounded-lg hover:bg-white/90 disabled:opacity-50"
                    >
                      Ekle
                    </button>
                  </div>
                </form>
              ) : (
                <button
                  onClick={() => setIsAdding(true)}
                  className="flex items-center w-full gap-3 p-4 mb-4 transition-colors rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 border-dashed"
                >
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white/10">
                    <Plus className="w-4 h-4" />
                  </div>
                  <span className="font-medium">Yeni Ders Ekle</span>
                </button>
              )}

              <div className="space-y-2">
                {dersler.map(ders => (
                  <div
                    key={ders.id}
                    className={`flex items-center justify-between p-4 rounded-xl transition-all cursor-pointer border ${activeDersId === ders.id ? 'bg-white/10 border-white/30 shadow-lg' : 'hover:bg-white/5 border-transparent'}`}
                    onClick={() => {
                      onSelect(ders.id);
                      onClose();
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-4 h-4 rounded-full shadow-sm"
                        style={{ backgroundColor: ders.color }}
                      />
                      <span className="font-medium">{ders.name}</span>
                    </div>
                    {activeDersId !== ders.id && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteDers(ders.id);
                        }}
                        className="p-2 text-white/40 transition-colors rounded-full hover:text-red-400 hover:bg-red-400/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
