import { motion, AnimatePresence } from 'framer-motion';
import { X, BarChart3, Clock, CalendarDays, Trash2 } from 'lucide-react';
import { useSeanslar } from '../hooks/use-seanslar';
import { useDersler } from '../hooks/use-dersler';

interface StatsViewProps {
  isOpen: boolean;
  onClose: () => void;
}

export function StatsView({ isOpen, onClose }: StatsViewProps) {
  const { seanslar, clearSeanslar } = useSeanslar();
  const { dersler } = useDersler();

  const formatDuration = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    
    if (h > 0) return `${h}s ${m}dk`;
    if (m > 0) return `${m}dk ${s}sn`;
    return `${s}sn`;
  };

  const getTodayTotal = () => {
    const today = new Date().toDateString();
    const total = seanslar
      .filter(s => new Date(s.baslamaSaati).toDateString() === today)
      .reduce((acc, s) => acc + s.sure, 0);
    return formatDuration(total);
  };

  const getAllTimeTotal = () => {
    const total = seanslar.reduce((acc, s) => acc + s.sure, 0);
    return formatDuration(total);
  };

  // Group by subject
  const subjectTotals = seanslar.reduce((acc, s) => {
    acc[s.dersId] = (acc[s.dersId] || 0) + s.sure;
    return acc;
  }, {} as Record<string, number>);

  const sortedSubjects = Object.entries(subjectTotals)
    .sort(([, a], [, b]) => b - a)
    .map(([id, total]) => ({
      ders: dersler.find(d => d.id === id),
      total
    }))
    .filter(item => item.ders);

  const maxTotal = sortedSubjects.length > 0 ? sortedSubjects[0].total : 1;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
        >
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
            className="w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden rounded-3xl glass-panel text-white"
          >
            <div className="flex items-center justify-between p-6 border-b border-white/10 shrink-0">
              <div className="flex items-center gap-3">
                <BarChart3 className="w-6 h-6 text-white/80" />
                <h2 className="text-xl font-semibold">İstatistikler</h2>
              </div>
              <button
                onClick={onClose}
                className="p-2 transition-colors rounded-full hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1 space-y-8">
              {/* Summary Cards */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-5 rounded-2xl bg-white/5 border border-white/10">
                  <div className="flex items-center gap-2 mb-2 text-white/60">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm font-medium">Bugün</span>
                  </div>
                  <div className="text-2xl font-bold font-mono tracking-tight">{getTodayTotal()}</div>
                </div>
                <div className="p-5 rounded-2xl bg-white/5 border border-white/10">
                  <div className="flex items-center gap-2 mb-2 text-white/60">
                    <CalendarDays className="w-4 h-4" />
                    <span className="text-sm font-medium">Toplam</span>
                  </div>
                  <div className="text-2xl font-bold font-mono tracking-tight">{getAllTimeTotal()}</div>
                </div>
              </div>

              {/* Chart */}
              {sortedSubjects.length > 0 && (
                <div>
                  <h3 className="mb-4 text-sm font-medium text-white/60 uppercase tracking-wider">Derslere Göre Dağılım</h3>
                  <div className="space-y-4">
                    {sortedSubjects.map((item) => (
                      <div key={item.ders!.id} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.ders!.color }} />
                            {item.ders!.name}
                          </span>
                          <span className="font-mono text-white/80">{formatDuration(item.total)}</span>
                        </div>
                        <div className="w-full h-3 rounded-full bg-white/10 overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${(item.total / maxTotal) * 100}%` }}
                            transition={{ duration: 1, ease: "easeOut" }}
                            className="h-full rounded-full"
                            style={{ backgroundColor: item.ders!.color }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Recent Sessions */}
              {seanslar.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-medium text-white/60 uppercase tracking-wider">Son Çalışmalar</h3>
                    <button onClick={clearSeanslar} className="text-xs text-white/40 hover:text-red-400 flex items-center gap-1 transition-colors">
                      <Trash2 className="w-3 h-3" />
                      Temizle
                    </button>
                  </div>
                  <div className="space-y-2">
                    {seanslar.slice(0, 10).map((seans) => {
                      const ders = dersler.find(d => d.id === seans.dersId);
                      const date = new Date(seans.baslamaSaati);
                      return (
                        <div key={seans.id} className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5">
                          <div>
                            <div className="font-medium flex items-center gap-2 mb-1">
                              {ders && <span className="w-2 h-2 rounded-full" style={{ backgroundColor: ders.color }} />}
                              {seans.dersAdi}
                            </div>
                            <div className="text-xs text-white/50 flex items-center gap-2">
                              <span>{date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>
                              <span className="w-1 h-1 rounded-full bg-white/30" />
                              <span className="capitalize">{seans.mod}</span>
                            </div>
                          </div>
                          <div className="font-mono font-medium text-white/90">
                            {formatDuration(seans.sure)}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {seanslar.length === 0 && (
                <div className="text-center py-12 text-white/40">
                  <Clock className="w-12 h-12 mx-auto mb-4 opacity-20" />
                  <p>Henüz kayıtlı çalışma bulunmuyor.</p>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
